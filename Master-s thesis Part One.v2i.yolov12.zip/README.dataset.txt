# Master's thesis Part One > 2023-10-02 12:07pm
https://universe.roboflow.com/iu-internationale-hochschule/master-s-thesis-part-one

Provided by a Roboflow user
License: CC BY 4.0

